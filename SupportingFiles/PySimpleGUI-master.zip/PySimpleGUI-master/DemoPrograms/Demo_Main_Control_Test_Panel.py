import PySimpleGUI as sg

"""
    This is a simple as it gets.  Calls the "main" function which is the PySimpleGUI Test Harness
    or Control Panel of sorts.   Use it to view themes, upgrade your PySimpleGUI to the GitHub version, etc.
"""

sg.main()

