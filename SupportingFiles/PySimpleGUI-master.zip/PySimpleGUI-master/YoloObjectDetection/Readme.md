
# PySimpleGUI openCV YOLO Deep Learning

To save room in the PySimpleGUI Repo, this project has been moved to its own repo on GitHub

You'll now find the project at: https://github.com/PySimpleGUI/PySimpleGUI-YOLO
