//
//  libavg - Media Playback Engine.
//  Copyright (C) 2003-2021 Ulrich von Zadow
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Lesser General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//  Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public
//  License along with this library; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//  Current versions can be found at www.libavg.de
//

#ifndef _GPUHueSatFilter_H_
#define _GPUHueSatFilter_H_

#include "../api.h"

#include "GPUFilter.h"
#include "MCShaderParam.h"

namespace avg {

class AVG_API GPUHueSatFilter: public GPUFilter
{
public:
    GPUHueSatFilter(const IntPoint& size, bool bUseAlpha, bool bStandalone=true);
    virtual ~GPUHueSatFilter();

    virtual void applyOnGPU(GLContext* pContext, GLTexturePtr pSrcTex);
    void setParams(int hue, int saturation=1, int lightness_offset=0,
            bool colorize=false);

private:
    float m_LightnessOffset;
    float m_Hue;
    float m_Saturation;
    bool m_bColorize;

    FloatMCShaderParamPtr m_pHueParam;
    FloatMCShaderParamPtr m_pSatParam;
    FloatMCShaderParamPtr m_pLightnessParam;
    IntMCShaderParamPtr m_pColorizeParam;
    IntMCShaderParamPtr m_pTextureParam;
};

typedef boost::shared_ptr<GPUHueSatFilter> GPUHueSatFilterPtr;

}
#endif
